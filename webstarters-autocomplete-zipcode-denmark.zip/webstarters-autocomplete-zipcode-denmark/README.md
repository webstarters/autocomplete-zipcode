=== Webstarters autocomplete zipcodes ===
Contributors: Webstarters
Requires at least: 4.9
Tested up to: 5.0
Stable tag: 5.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

# Autocomplete zipcodes denmark

Et WordPress-plugin der er bliver benyttet af Woocommerce til at auto udfylde post numre i Danmark.

Softwaren her, benytter sig af data fra https://dawa.aws.dk

## Credit
- [Jesper Kaae](https://github.com/jesperkaae)

## License

© Webstarters A/S.